let cart = JSON.parse(localStorage.getItem("cart")) || [];
function addToCart(name, price) {
  cart.push({ name, price });
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${name} added to cart`);
}
function displayCart() {
  const cartItems = document.getElementById("cart-items");
  const totalSpan = document.getElementById("total");
  if (!cartItems || !totalSpan) return;
  cartItems.innerHTML = "";
  let total = 0;
  cart.forEach((item, index) => {
    const li = document.createElement("li");
    li.textContent = `${item.name} - Ksh ${item.price}`;
    cartItems.appendChild(li);
    total += item.price;
  });
  totalSpan.textContent = `Ksh ${total}`;
}
document.addEventListener("DOMContentLoaded", displayCart);


// Modify cart rendering to show product image
function renderCart() {
  const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
  const cartContainer = document.getElementById('cart-items');
  cartContainer.innerHTML = '';

  cartItems.forEach(item => {
    const div = document.createElement('div');
    div.className = 'cart-item';
    div.innerHTML = `
      <img src="${item.image}" alt="${item.name}" class="cart-thumb">
      <div>
        <p>${item.name}</p>
        <p>Ksh ${item.price}</p>
      </div>
    `;
    cartContainer.appendChild(div);
  });
}
